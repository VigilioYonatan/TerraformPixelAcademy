terraform {
  required_version = ">= 1.9.0, < 2.0.0"
}

variable "environment" { type = string }
resource "terraform_data" "service" {
  input = "${var.environment}-service"
}
output "id" { value = terraform_data.service.id }
