# S18 · Hito 01: Arquitectura y ownership

**Objetivo:** Diagrama de capas, matriz RACI y ADR de ownership Terraform/GitOps.

## Entregable esperado

1. Describir la decisión técnica específica del hito y alternativas.
2. Identificar owner, entorno, límites de permisos y riesgos.
3. Registrar una evidencia rastreable (archivo/commit/hash/log) o `NOT_RUN`.
4. Explicar un criterio GO/NO-GO y procedimiento de reversión.

## Registro del estudiante

- Estado: NOT_RUN
- Fecha y responsable:
- Artefacto / enlace / hash:
- Decisión:
- Prueba o simulación ejecutada:
- Riesgo residual:
- Rollback:
- Revisión por pares: NOT_RUN

> Este archivo es una plantilla para completar, no evidencia validada.
