# ADR — S14: Aumento de costos sin control

- Estado: PROPUESTA
- Fecha:
- Responsable:
- Entorno y blast radius:

## Problema y contexto

## Opciones evaluadas

### Opción A

### Opción B

## Decisión y justificación

## Riesgos residuales

## Validación y resultados (con procedencia: PASS/FAIL/NOT_RUN/BLOCKED)

## Rollback y responsables

## Referencias / evidencia verificable
